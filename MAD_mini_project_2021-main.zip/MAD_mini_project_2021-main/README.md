# MAD_mini_project_2021
 this mobile application was made by Abhishek k, Sai Sree Varun, Kushal Gowda and Sri Ram
