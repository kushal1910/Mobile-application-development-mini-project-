package com.android.udacity_foodquest.ui.cuisineslist;

import com.android.udacity_foodquest.model.cuisines.Cuisine;

public interface CuisinesListCallback {
    void onCouisineClick(Cuisine cuisine);
}
