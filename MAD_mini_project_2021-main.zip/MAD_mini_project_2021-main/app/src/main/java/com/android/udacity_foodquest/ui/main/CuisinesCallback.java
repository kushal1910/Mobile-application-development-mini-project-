package com.android.udacity_foodquest.ui.main;

import com.android.udacity_foodquest.model.cuisines.Cuisine;

public interface CuisinesCallback {
    void onMainCuisineClick(Cuisine cuisine);
}
