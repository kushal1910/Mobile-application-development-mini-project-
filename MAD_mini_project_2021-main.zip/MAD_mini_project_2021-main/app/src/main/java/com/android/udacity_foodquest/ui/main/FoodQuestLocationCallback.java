package com.android.udacity_foodquest.ui.main;

public interface FoodQuestLocationCallback {
    void onCurrentLocationClick();
    void onSaveLocationClick(String value);
}
